//�ؿ�����,zl,2015-05-25
var m_arrgate = [];

m_arrgate.push({"questid":123,"levelid":0});
m_arrgate.push({"questid":124,"levelid":0});
m_arrgate.push({"questid":125,"levelid":1});

