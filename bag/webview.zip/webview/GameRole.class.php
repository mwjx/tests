<?php
	class GameRole {
		public $mysqli = null;
		function __construct($host,$user,$pwd ,$db,$port){
			$this->tabName = "CHARBASE";
			$this->setDb($host,$user,$pwd ,$db,$port);
		}
		private function setDb($host,$user,$pwd ,$db,$port){
			$this->host =$host;
			$this->user = $user;
			$this->pwd = $pwd;
			$this->db = $db;
			$this->mysqli= new mysqli($host,$user,$pwd,$db,$port);
			$this->mysqli->query("set names utf8");
			if(mysqli_connect_errno()) {
				$this->mysqli=FALSE;
				exit();
			}			 
		}
		function getCharidByAccid($where ="1=1"){
			$sql = "SELECT `ACCID`,`CHARID`,`GAME_ZONE`,`NAME` FROM `".$this->tabName."` WHERE ".$where;
			$result=$this->mysqli->query($sql);
			while($result && $aRow = $result->fetch_assoc() ){
				$data= $aRow;
			}
			return $data;
		}
	}
?>
