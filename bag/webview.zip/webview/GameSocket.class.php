<?php
class GameSocket {
	protected $socket;
	protected $packLen;
	protected $packHead;
	protected $readCount=0;
	protected $writeCount=0;
	public $writeQueue = array();
	public $readQueue  = array();
	public $globalBuffer='';	//套接口缓冲
	//public $jret = array();	//响应返回值,key=>ret
	const COMPRESS = 0x40000000;	//压缩
	const UseCompress = true;
	public static $_instance;
	static function getInstance() {
		if (self::$_instance == null)
			self::$_instance = new GameSocket ();
		return self::$_instance;
	}
	function getSocket() {
		return $this->socket;
	}
	//套接口连接错误原因
	public function getSocketErrorMsg(){
		$error = socket_last_error ($this->socket);
		return socket_strerror ( $error );
	}
	//创建套接口
	public function initSocket() {
		$this->socket = socket_create ( AF_INET, SOCK_STREAM, SOL_TCP );
		if(! $this->socket) {
			log1 ( "gamesocket-".date("Y-m-d"), $this->getSocketErrorMsg() );
			return false;
		}
		return true;
	}
	//关闭套接口
	public function closeSocket(){
		socket_close($this->socket);
	}
	//连接套接口
	public function connectSocket($ip, $port) {
		if(!$this->socket){		//func:initSocket
			$this->initSocket();
		}
		$ret = socket_connect ( $this->socket, $ip, $port );
		if (! $ret) {
			log1 ( "gamesocket-".date("Y-m-d"), "socket_connect()...{$ip}:{$port},出错!" );
			return false;
		}
		return $this->socket;
	}
	//检查可读性
	public function isBytesReadAvailable() {
		//socket_select($reaf[一组等待可读性检查得到套接口], $write[一组等待可写性检查的套接口], $except[一组等待错误检查的套接口], $tv_sec[最多等待时间,非阻塞方式])
		$num_changed_sockets = 0;
		$this->readCount = 0;
		while($num_changed_sockets <= 0){
			$r = $w = $e = array ();
			$r = array($this->socket);
			$num_changed_sockets = socket_select ( $r, $w, $e, 0);	
			//连接失败
			if ($num_changed_sockets === false){
				log1 ( "gamesocket-".date("Y-m-d"), $this->getSocketErrorMsg());
				return false;
			}
			if($num_changed_sockets > 0)
				return true;
			sleep(1);
			$this->readCount++;
			//log1("gamesocket-".date("Y-m-d"),"socket_select...read...{$this->readCount}s");
  			if($this->readCount>=60){
  				log1("gamesocket-".date("Y-m-d"),"socket_select...read...failure");
  				return false;
  			}
		}
		return true;
	}
	//检查可写性
	public function isBytesWriteAvailable() {	
		$num_changed_sockets = 0;
		while($num_changed_sockets<=0){
			$this->writeCount++;
			$r = $w = $e = array ();			
			$w = array($this->socket);			
			$num_changed_sockets = socket_select ( $r, $w, $e,  0);	

			if ($num_changed_sockets === false) {
				log1 ( "gamesocket-".date("Y-m-d"), $this->getSocketErrorMsg() );
				return false;
			}
			if( $num_changed_sockets > 0)
				return true;
			sleep(1);
			if($this->writeCount == 60){
				log1("gamesocket-".date("Y-m-d"),"socket_select...write...{$this->writeCount}s");
				return false;
			}
		}
		return true;
	}
	//处理客户端的输入并返回处理后的数据,使得由通信socket发回一个数据流到客户端成为可能.一旦输出被返回到客户端,父/子socket都应通过socket_close来终止
	public function write() {	//接受客户端信息后返回至客户端的信息	
		$writeQueue = $this->writeQueue;		
		if(empty($writeQueue) || !is_array($writeQueue) || count($writeQueue)<=0){
			return false;
		}
		while(!empty($writeQueue) && is_array($writeQueue) && count($writeQueue)){
			$instruct = array_shift($writeQueue);
			$size = socket_write($this->socket, $instruct);
			if ($size === false) {
				log1("gamesocket-".date("Y-m-d"),"socket_write...".$this->getSocketErrorMsg());
				return false;
			}
			if($size>0){
				//log1("gamesocket-".date("Y-m-d"),"socket_write...size...".$size."byte");
				$this->writeQueue = $writeQueue;
				return true;
			}else{
				log1("gamesocket-".date("Y-m-d"),"socket_write...size...0byte");
			}
		}
	}
	//获取客户端输入的信息
	public function read() {	//显示在服务器端的信息		
		$buf = socket_read ( $this->socket, 4096, PHP_BINARY_READ ); 	
		//参数:套接口 限制从客户段获取数据的大小(\n,\t,\0被视作结束符)	PHP_BINARY_READ(默认,接受由socket_recv()传递过来的数据)
		//返回值:成功返回字符串数据,失败返回false
		if($buf === false) {
			log1 ( "gamesocket.txt", " socket_read...".$this->getSocketErrorMsg()  );
			return false;
		}
 		$this->globalBuffer = $this->globalBuffer.$buf;
 		if(strlen($this->globalBuffer)>4096){
		//log1 ( "error-gamesocket-".date("Y-m-d"), " socket_read...globalBuffer...sizeof()=".strlen($this->globalBuffer) );
 			log1("error-gamesocket.txt", " socket_read...globalBuffer...sizeof()=".strlen($this->globalBuffer) );
 			return false;
 		} 		
 		$_count_process=0;
 		while(strlen($this->globalBuffer)>=4){
 			$_count_process ++; 			
 			$this->process();
 			if($_count_process==60) {
 				log1("error-gamesocket.txt","process time pass 60");
 				return false;
 			}
 		}
 		return true;
	}
	public function process(){		
		$gBuf = $this->globalBuffer;		
		$len = strlen($gBuf);		
		if($len>=4){			
			$rawhead	= substr($gBuf,0,4);
			$ret 		= unpack("Ihead",$rawhead);
			$head 		= $ret['head'];
			$packLen    = $head; 
			if (($head & self::COMPRESS) && self::UseCompress) {
				$packLen = ($head ^ self::COMPRESS);
			}
			//log1("gamesocket-".date("Y-m-d"),"实际的缓冲长度-->".$len."描述的包长度-->".$packLen."头大小4");
			if($packLen>$len-4){
				log1("error-gamesocket","包数据实际长度小于指令中描述的数据长度");
				die('包数据实际长度小于指令中描述的数据长度'.($packLen."-".($len-4)));//包数据实际长度小于指令中描述的数据长度
			}			
			$gBuf = substr($gBuf,4);  //截断包头数据
			$data = substr($gBuf,0,$packLen);//含CMD+PARAM+timstamp的数据			
			$gBuf = substr($gBuf,$packLen);//截断指令大小(4+packLen)数据			
			$this->globalBuffer = $gBuf; //保留未完成的buffer			
			if (($head & self::COMPRESS) && self::UseCompress) {
				$data = gzuncompress($data);
			}
			array_push($this->readQueue, $data); //PHP所有服务器指令取自readQueue
			$this->dispatch();
			$len = $len-(4+$packLen);	//计算新的长度
		}
	}
	public function dispatch(){//cmd+param+data
 		$readQueue = $this->readQueue;
		while(!empty($readQueue) && is_array($readQueue) && count($readQueue)>0){
			$instruct 	= array_shift($readQueue);
			$this->readQueue = $readQueue ;
			$retbasic = unpack("CbyCmd/CbyParam/Itime",substr($instruct, 0,6));
			//log1("gamesocket","byCmd=".$retbasic['byCmd'].",byParam=".$retbasic['byParam']);
			switch($retbasic['byParam']){
				case req_json_cmd::CMD_REQ_JSON: //json通用
					log1("xxx.txt","json通用返回");
					$format = req_json_cmd::getformat();
					$retcmd = unpack($format ,$instruct);
					log1("xxx.txt","json txt:".$retcmd["txt"]);
					$_SESSION['RETJSON'] = $retcmd["txt"];
					break;
				case ReturnLoginGmUserCmd::RETURN_LOGIN_GM_USERCMD_PARA:
					$format = ReturnLoginGmUserCmd::getformat();
					$retcmd = unpack($format , $instruct);
					$_SESSION['GMPRI'] = $retcmd['retcod']."|".$retcmd['gmID']."|". $retcmd['pri'];
					break;
				case ReturnZoneDicGmUserCmd::RETURN_ZONE_DIC_GM_USERCMD_PARA:
					 $ret = unpack("vnum",substr($instruct,6,2));
					 $rawzone 	= substr($instruct,8);
					 $num = $ret['num'];
					 $zoneList = array();
					 if($num>0){
					 	for($i=0;$i<$num;$i++){
					 		$ret = unpack ( "Izoneid/a33name", substr($rawzone,0,37));
							$zone  = $ret['zoneid'];
							$game = $ret['name'];
							$game = gbktoutf8($game);
							array_push($zoneList, $zone."-".$game);
							$rawzone =  substr($rawzone,37);
					 	}
 					}
					break;
				case RedeemReturn_GmTool::PARA_REDEEM_RETURN_GMTOOL:
					$ret = unpack("Csuc",substr($instruct,-1,1));
					$suc = $ret['suc'];
					//$instruct = substr($instruct,6);
					$instruct = substr($instruct,10);
					$gz = unpack ( "vzoneid/vgame", substr($instruct,0,4));//注意：只有4个字节
					$game =  $gz['game'];
					$zondid =  $gz['zoneid'];
					$instruct = substr($instruct,4);
					$name = unpack("a33name",substr($instruct,0,33));//33个字节
					$instruct = substr($instruct,33);
					$gmName = unpack("a33name",substr($instruct,0,33));
					$instruct = substr($instruct,33);
					$_SESSION["CMD".RedeemReturn_GmTool::PARA_REDEEM_RETURN_GMTOOL] = $suc;
					break;
				case Group_redeem_Return_GmTool::PARA_GROUP_REDEEM_RETURN_GMTOOL:
					$format = Group_redeem_Return_GmTool::getformat(); 
					$retcmd = unpack($format , $instruct);
					log1("gamesocket-".date("Y-m-d"),"S->C...PARA_GROUP_REDEEM_RETURN_GMTOOL...".$retcmd['byCmd']."|".$retcmd['byParam']."|".$retcmd['time']."|".$retcmd['zone']."|".$retcmd['gmName']."|".$retcmd['ret']);
					$_SESSION["CMD".Group_redeem_Return_GmTool::PARA_GROUP_REDEEM_RETURN_GMTOOL] = $retcmd['ret'];
					break;
				case PunishReturn_GmTool::PARA_PUNISH_RETURN_GMTOOL:
					$format = PunishReturn_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					//log1('debug'.__TODAY,"[处罚]结果返回,ret=".$retcmd['ret']);
					//"CbyCmd/CbyParam/Itime/Izone/a33username/a33gmName/voperation/Cret"
					log1('debug'.__TODAY,"[处罚]结果返回,S->C...PARA_PUNISH_RETURN_GMTOOL...".$retcmd['byCmd']."|".$retcmd['byParam']."|".$retcmd['time']."|".$retcmd['zone']."|".$retcmd['charid']."|".gbktoutf8($retcmd['username'])."|".$retcmd['gmName']."|".$retcmd['operation']."|".$retcmd['ret']);
					$_SESSION['CMD'.PunishReturn_GmTool::PARA_PUNISH_RETURN_GMTOOL] = $retcmd['ret'];
					break;
				case BroadcastReturn_GmTool::PARA_BROADCAST_RETURN_GMTOOL:
					$format = BroadcastReturn_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					//CbyCmd/CbyParam/Itime/Izone/Iid/a33gmName/Cret
					log1("xxx.txt","S->C...PARA_BROADCAST_RETURN_GMTOOL...".$retcmd['byCmd']."|".$retcmd['byParam']."|".$retcmd['time']."|".$retcmd['zone']."|".$retcmd['id']."|".$retcmd['gmName']."|".$retcmd['ret']);
					//log1("gamesocket-".date("Y-m-d"),"S->C...PARA_BROADCAST_RETURN_GMTOOL...".$retcmd['byCmd']."|".$retcmd['byParam']."|".$retcmd['time']."|".$retcmd['zone']."|".$retcmd['id']."|".$retcmd['gmName']."|".$retcmd['ret']);
					$_SESSION[BroadcastReturn_GmTool::PARA_BROADCAST_RETURN_GMTOOL] = $retcmd['ret'];
					break;
				case Log_GmTool::PARA_LOG_GMTOOL:
					$format = Log_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					//CbyCmd/CbyParam/Itime/IcharID/IaccID/a33gmName/a33pos/a64content/Cstate
					log1("gamesocket-".date("Y-m-d"),"S->C...PARA_LOG_GMTOOL...".$retcmd['byCmd']."|".$retcmd['byParam']."|".$retcmd['zone']."|".$retcmd['time']."|".$retcmd['charID']."|".$retcmd['accID']."|".$retcmd['gmName']."|".$retcmd['pos']."|".$retcmd['content']."|".$retcmd['state']);
					$retStr = Log_GmTool::PARA_LOG_GMTOOL.urlencode($retcmd['gmName']);
					$md5RetStr = md5($retStr);
					$_SESSION[$md5RetStr] = $retcmd['state'];
					break;
				case st_RspUploadConfGmTool::RSP_UPLOAD_CONF_GMTOOL:	//响应上传配置
					$format = st_RspUploadConfGmTool::getformat();
					$retcmd = unpack($format , $instruct);
					log1("debug".__TODAY,"[上传配置]响应,cmd=".$retcmd['byCmd'].",para=".$retcmd['byParam'].",name=".$retcmd['gmName'].",ret=".$retcmd['ret']);
					$retStr = st_RspUploadConfGmTool::RSP_UPLOAD_CONF_GMTOOL.urlencode($retcmd['gmName']);
					$md5RetStr = md5($retStr);
					$_SESSION[$md5RetStr] = $retcmd['ret'];
					break;
				case Ret_User_Lucky_GmTool::RET_USER_LUCKY_GMTOOL:
					$format = Ret_User_Lucky_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					$retStr = Ret_User_Lucky_GmTool::RET_USER_LUCKY_GMTOOL.urlencode($retcmd['gmName']);
					$md5RetStr = md5($retStr);
					$_SESSION[$md5RetStr] = $retcmd['ret'];
					$zone = $retcmd['zone'];
					$gmName = $retcmd['gmName'];
					$userName = $retcmd['userName'];
					$ret = $retcmd['ret'];
					$luck = array();
					if($ret){	
						for($i=0;$i<5;$i++){
							$luck[$i]['nowLucky'] = $retcmd['nowLucky'.$i];
							$luck[$i]['nowNoBindTimes'] = $retcmd['nowNoBindTimes'.$i];
							$luck[$i]['nowBindTimes'] = $retcmd['nowBindTimes'.$i]; 
						}
						$retStr  = Ret_User_Lucky_GmTool::RET_USER_LUCKY_GMTOOL;
						$retStr .= $retcmd['zone'];
						$retStr .= urlencode($gmName);
						$retStr .= gbktoutf8($userName);
						$_SESSION["CMD".Ret_User_Lucky_GmTool::RET_USER_LUCKY_GMTOOL] = serialize($luck);
						//log1("gamesocket-".date("Y-m-d"),"S->C...RET_USER_LUCKY_GMTOOL...".serialize($luck));
					}else{
						log1("gamesocket-".date("Y-m-d"),"S->C...RET_USER_LUCKY_GMTOOL...suc?".$ret);
					}	
					break;
				case ChangeUserOneLucky_Return_GmTool::CHANGE_USER_ONE_LUCKY_RETURN_GMTOOL:
					$format = ChangeUserOneLucky_Return_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					//CbyCmd/CbyParam/Itime/Izone/a33gmName/a33userName/Cret
					$zone = $retcmd['zone'];
					$gmName = $retcmd['gmName'];
					$userName = $retcmd['userName'];
					$ret = $retcmd['ret'];
					$_SESSION["CMD".ChangeUserOneLucky_Return_GmTool::CHANGE_USER_ONE_LUCKY_RETURN_GMTOOL] = $ret;
					break;
				case RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL:
					$format = RefreshOnlineNum_GmTool::getformat();
					$retcmd = unpack($format , $instruct);
					//CbyCmd/CbyParam/Itime/Izone/vonlineNum/a33gmName
					$zone = $retcmd['zone'];
					$onlineNum = $retcmd['onlineNum'];
					$userName = $retcmd['gmName'];
					//log1("realOnline_error_".date("Y-m-d"),$zone."-".$onlineNum);
					log1("realOnline_error.txt",$zone."-".$onlineNum.",zoneid=".":".('CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.$zone));
					$_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.$zone] = $onlineNum;
					break;
				case stReturnOnlineLVGmUserCmd::RETURN_ONLINE_LV_GM_USERCMD_PARA:	//响应在线等级分布
 					log1("gamesocket",date("Y-m-d")."S->C...RETURN_ONLINE_LV_GM_USERCMD_PARA...");
					$ret = unpack("vsize",substr($instruct,43,2));
					$rawzone = substr($instruct,45);
					$size = $ret['size'];
					//log1("gamesocket","size=".$size);
					$mplv = array();
					if($size<1){
						$_SESSION["CMD".stReturnOnlineLVGmUserCmd::RETURN_ONLINE_LV_GM_USERCMD_PARA] = serialize($mplv);
						break;
					}
					for($i=0;$i<$size;++$i){
						$ret = unpack("Ilv/Inum",substr($rawzone,0,8));
						$lv  = $ret['lv'];
						$num = $ret['num'];
						$rawzone =  substr($rawzone,8);
						$mplv[$lv] = $num;
					}
					$_SESSION["CMD".stReturnOnlineLVGmUserCmd::RETURN_ONLINE_LV_GM_USERCMD_PARA] = serialize($mplv);
					break;
				default:
					log1("gamesocket-".date("Y-m-d"),"php didnot process...".$retbasic['byCmd']."|".$retbasic['byParam']."|".$retbasic['time']);
					break;
			}
		}
	}
	//判断发送信息是否成功
	public function sendCmd1($cmd){
		if($this->isBytesWriteAvailable()){
			array_push($this->writeQueue,$cmd);
			return $this->write();
		}else{
			return false;
		}
	}
	//判断接受信息是否成功
	public function readCmd1(){
		if($this->isBytesReadAvailable()){
			return $this->read();
		}else{
			return false;
		}
	}
	//判断GM权限
	public function gmPri(){
		if($_SESSION['GMPRI']){
			$arPri = explode("|", $_SESSION['GMPRI']);
			unset($_SESSION['GMPRI']);
			if($arPri[0]== ReturnLoginGmUserCmd::ReturnLoginGmType_Error_Passwd){
				return 'GM密码错误';
			}
			if($arPri[0]==ReturnLoginGmUserCmd::ReturnLoginGmType_Error_NoUser){
				return 'GM用户不存在';
			}
			if($arPri[0]==ReturnLoginGmUserCmd::ReturnLoginGmType_Error_None){
				return  '未知错误 ';
			}
			if($arPri[0]==ReturnLoginGmUserCmd::ReturnLoginGmType_Error_Using){
				return  'GM帐号正在使用 ';
			}
			if($arPri[0]==ReturnLoginGmUserCmd::ReturnLoginGmType_Error_Version){
				return 'GM权限错误 ';
			}
			if($arPri[0]==ReturnLoginGmUserCmd::ReturnLoginGmType_End){
				return 'GM登陆数据发送结束 ';
			}
		}else{
			return '会话信息错误';
		}
		return 1;
	}
} //end GameSocket

//----------------开始指令定义--------------
class NullUserCmd {
	public $byCmd; // BYTE
	public $byParam; // BYTE
	public $dwTimestamp = 0; // DWORD
	public function __construct(){
		$this->byCmd = pack("C",$this->byCmd);
		$this->byParam = pack("C",$this->byParam);
		$this->dwTimestamp = pack("I",$this->dwTimestamp);
	}
	public function getBasicInstructs(){
		return $this->byCmd.$this->byParam.$this->dwTimestamp.pack("I",0);
	}
	public function getCompressInstructs($data){
		$len = strlen($data);
		$uintHead = pack ( "I",   $len);
		if ( $len > 32 ){
			$data 		= 	gzcompress ( $data, 9 );
			$len  		= 	strlen ( $data );
			$uintHead 	=   pack ( "I", ($len + 0x40000000) ); // four byte
		}
		$data = $uintHead.$data;
		return $data;
	}
}

class GmToolUserCmd extends NullUserCmd{
	/**
	 * GM命令开始的第一个参数
	 */
	const GMTOOL_USERCMD = 34;
	public function __construct(){
		$this->byCmd = self::GMTOOL_USERCMD;
		parent::__construct();
	}
}
//通用json指令
class req_json_cmd extends GmToolUserCmd{
	const CMD_REQ_JSON = 28;
	const JSON_TXT_MAX = 2048; //json数据最大长度
	public $byParam; //子命令
	public $txt; //json的文本
	public function __construct($s=''){
		log1("gamesocket.txt","C->S...CMD_REQ_JSON...".$s);
		$this->byParam = self::CMD_REQ_JSON;
		$this->txt  = pack("a".strlen($s).("@".self::JSON_TXT_MAX),$s);
		parent::__construct();
	}
	public function getCmd(){
		$data = $this->getBasicInstructs();
		$data = $data.$this->txt;
		$data = $this->getCompressInstructs($data);
		return $data;
	}
	public static function getformat() {
		$format = "CbyCmd/CbyParam/Itime/Itime2/a".self::JSON_TXT_MAX."txt";
		return $format;
	}
}
class RequestLoginGmUserCmd extends GmToolUserCmd{
	/**
	 * ******请求登陆的参数**
	 */
	const REQUEST_LOGIN_GM_USERCMD_PARA = 1;
	public $gmName;
	public $password;
	public $byParam;
	public function __construct($u='A1',$p='A1'){
		$this->byParam = self::REQUEST_LOGIN_GM_USERCMD_PARA;
		$this->gmName  = pack("a".strlen($u)."@33",$u);
		$this->password = pack("a".strlen($p)."@17",$p);
		parent::__construct();
	}
	public function getCmd(){
		$data = $this->getBasicInstructs();
		$data = $data.$this->gmName.$this->password;
		$data = $this->getCompressInstructs($data);
		return $data;
	}
}
class ReturnLoginGmUserCmd extends GmToolUserCmd {
	/**
	 * ******GM登陆返回的参数*
	 */
	const RETURN_LOGIN_GM_USERCMD_PARA = 2;
	/**
	 * 登陆类型返回retcod**
	 */
	const ReturnLoginGmType_OK = 0;
	const ReturnLoginGmType_Error_Passwd = 1;  /**< 密码错误 */
	const ReturnLoginGmType_Error_NoUser = 2;  /**< 用户不存在 */
	const ReturnLoginGmType_Error_None = 3;   /**< 未知错误 */
	const ReturnLoginGmType_Error_Using = 4;   /**< 帐号正在使用 */
	const ReturnLoginGmType_Error_Version = 5; /**< 权限错误 */
	const ReturnLoginGmType_End = 6; /**< 登陆数据发送结束 */	
	public $retcod; // BYTE 22 2 800 9000000
	public $gmID;
	public $pri;
	public function __construct() { // C3IC
		parent::__construct ();
	}
	public static function getformat() {
		return  "CbyCmd/CbyParam/Itime/Itime2/Cretcod/VgmID/Cpri";
	}
}
/**
 * *******请求所有游戏区及其名称*************
 */
class RequestZoneDicGmUserCmd extends GmToolUserCmd {
	const REQUEST_ZONE_DIC_GM_USERCMD_PARA = 18;
	public function __construct() {
		log1("gamesocket",date("Y-m-d")."C->S...REQUEST_ZONE_DIC_GM_USERCMD_PARA...");
		$this->byParam = self::REQUEST_ZONE_DIC_GM_USERCMD_PARA;
		parent::__construct();
	}
	public function getCmd(){
		$data = $this->getBasicInstructs();
		$data = $this->getCompressInstructs($data);
		return $data;
	}
}
// 返回所有游戏区及其名称
class ReturnZoneDicGmUserCmd extends  GmToolUserCmd {
	/**
	 * *******返回所有游戏区号及其名称******
	 */
	const RETURN_ZONE_DIC_GM_USERCMD_PARA = 19;
	protected $num; // WORD
	// zoneid和name连再一起构成结构体
	protected $zoneid; // DWORD
	protected $name; // [MAX_NAMESIZE];
	public function __construct() {
		parent::__construct();
	}
}
class Msg_GmTool extends GmToolUserCmd {
	/**
	 * *******GM定单*************
	 */
	const PARA_MSG_GMTOOL = 4;
	public $zone;
	public $userName;
	public $accid;
	public $country;
	public $type;
	public $content;
	public $contact;
	public $tele;
	public $isDeal;
	public $startTime;
	public $gmName;
	public function __construct($z,$u,$accid,$acountry,$type,$content,$contact,$tele,$isDeal,$startTime,$gmName) {
		parent::__construct ();
		$this->byParam = self::PARA_MSG_GMTOOL;
		$this->zone = $z;
		$this->userName = $u;
		$this->accid = $accid;
		$this->country = $acountry;
		$this->type = $type;
		$this->content = $content;
		$this->contact = $contact;
		$this->tele = $tele;
		$this->isDeal = $isDeal;
		$this->startTime = $startTime;
		$this->gmName =$gmName;
	}
	public function getCmd(){
		$data = $this->getBasicInstructs();
		$data = $this->getCompressInstructs($data);
		return $data;
	}
}
class Broadcast_GmTool extends GmToolUserCmd {
	/**
	 * *******公告参数************************
	 */
	const PARA_BROADCAST_GMTOOL = 7;
	public $zone;		//zoneid+game<<16
	public $country;
	public $content;
	public $time;
	public $interval;
	public $GM;
	public $id;
	public $mapID;
	public $showpos;		//WORD,显示位置
	public $issueTime;		//DWORD,开始时间
	public $effectTime;		//DWORD,生命时长
	public function __construct($z,$acountry, $content,$time,$interval,$GM,$id,$mapID,$spos,$issueTime=0,$effectTime=0) { 
		log1("gamesocket-".date("Y-m-d"),"C->S...PARA_BROADCAST_GMTOOL...".$z."|".$acountry."|".$content."|".$time."|".intval($interval)."|".$GM."|".$id."|".$mapID);
		$this->byParam = self::PARA_BROADCAST_GMTOOL;//顺序很重要
		parent::__construct ();
		$this->zone = pack("I",$z); 
		$this->country = pack("I",$acountry);
		$this->content = pack("a".strlen($content)."@256",$content);
		$this->time = pack("I",$time);
		$this->interval = pack("I",$interval);
		$this->GM = pack("a".strlen($GM)."@33",$GM); 
		$this->id = pack('I',$id);
		$this->mapID = pack("I",$mapID);
		$this->showpos = pack("v",$spos);
		$this->issueTime = pack("I",$issueTime);
		$this->effectTime = pack("I",$effectTime);
	}
	public function getCmd(){
		$data = $this->getBasicInstructs();
		$data =  $data.$this->zone.$this->country.$this->content.$this->time.$this->interval.$this->GM.$this->id.$this->mapID.$this->showpos.$this->issueTime.$this->effectTime;
		$data = $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
}
//发布公告是否成功
class BroadcastReturn_GmTool extends  GmToolUserCmd {
	/**
	 * *******发布公告是否成功******
	 */
	const PARA_BROADCAST_RETURN_GMTOOL  = 22;
	public  $zone; 		//game<<16+zoneid
	public  $id;   		//公告流水号DWORD
	public  $gmName; 	//gmName[MAX_NAMESIZE+1];
	public  $ret; 		//是否成功，1成功
	public function __construct() {
		parent::__construct();
	}
	public static function getformat() {
		return  "CbyCmd/CbyParam/Itime/Itime2/Izone/Iid/a33gmName/Cret";
	}
}
// 补偿
class Redeem_GmTool extends GmToolUserCmd {
	/**
	 * *******补偿参数++++++************
	 */
	const PARA_REDEEM_GMTOOL = 10;
	const MAX_REDEEM_LEN = 256;
	protected $zone;		//zoneid+game<<16
	protected $char_id;		// CHARID 
	protected $name;		// 玩家姓名
	protected $GM;			//GM姓名
	protected $type;		// 等于5为道具补偿
	protected $tid;			// 交易流水号
	protected $itemID;		// 补偿物品的ID
	protected $itemNum;		// 物品数量
	protected $isBind;		// 物品是否绑定,0不绑，1绑定
	protected $effectTime;	//有效时间
	protected $objls;		//多种道具
	public function __construct($z,$char_id, $name,$GM,$type,$tid,$itemID,$effectTime,$itemNum,$isBind,$objls=""){	
		$this->byParam = self::PARA_REDEEM_GMTOOL;
		parent::__construct ();
		$this->zone = pack("I",$z);
		$this->char_id = pack("I",$char_id);	 
		$this->name = pack("a".strlen($name)."@33",$name); 
		$this->GM = pack("a".strlen($GM)."@33",$GM);
		$this->type =  pack("C",$type);
		$this->tid = pack("a".strlen($tid)."@33",$tid);
		$this->itemID =  pack("I",$itemID);
		$this->itemNum =  pack("I",$itemNum);
		$this->isBind =  pack("C",$isBind);
		$this->effectTime = pack("I",$effectTime);
		$this->objls = pack("a".strlen($objls)."@".self::MAX_REDEEM_LEN,$objls);
	}
	public function getCmd(){   
		$data = $this->getBasicInstructs();
		$data =  $data.$this->zone.$this->char_id.$this->name.$this->GM.$this->type.$this->tid.$this->itemID.$this->itemNum.$this->isBind.$this->effectTime.$this->objls;
		$data = $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
}
class Punish_GmTool extends GmToolUserCmd {
	/**
	 * *******惩罚的参数+++++++++++++++*
	 */
	const PARA_PUNISH_GMTOOL = 6;
	/**
	 * *****处罚类型参数***********
	 */
	const p_init = 0; // 禁言
	const p_forbidVoice = 1; // 禁言
	const p_inPrison = 2; // 关禁闭
	const p_tickoff = 3; // * 踢下线
	const p_warning = 4; // 警告
	const p_ignoreVoice = 5; // 隐言
	const p_sayToSelf = 6; // 自言自语
	const p_forbidUser = 10; // 封停角色
	// GAME ZONE 构成struct
	protected $zone;		//game<<16+zoneid
	protected $charid;	 
	protected $country;
	protected $server;
	protected $GM;
	protected $reason; 		// 128byte
	protected $operation;
	protected $delay;
	protected $level;
	protected $accid;
	protected $startTime;
	public function __construct($z,$GM,$charid,$userName,$reason,$operation,$delay,$accid,$startTime) {
		log1("gamesocket-".date("Y-m-d"),"C->S...PARA_PUNISH_GMTOOL...".$z."|". $GM."|".$charid."|".gbktoutf8($userName)."|". $reason."|". $operation."|". $delay."|". $accid."|". $startTime);
		$this->byParam = self::PARA_PUNISH_GMTOOL;
		parent::__construct ();
		$gz = getGameZoneBySID($z);
		$this->zone = pack("I",$z);
		$this->GM = pack("a".strlen($GM)."@33",$GM);
		$this->charid = pack("I",$charid);
		$this->userName = pack("a".strlen($userName)."@33",$userName);
		$this->reason = pack("a".strlen($reason)."@128",$reason);
		$this->operation = pack("v",$operation);
		$this->delay = pack("I",$delay);
		$this->accid = pack("I",$accid);
		$this->startTime = pack("I",$startTime);
	}
	public function getCmd(){
		$data =  $this->getBasicInstructs();
		$data =  $data.$this->zone.$this->GM.$this->charid.$this->userName.$this->reason.$this->operation.$this->delay.$this->accid.$this->startTime;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
}

//惩罚返回
class PunishReturn_GmTool  extends  GmToolUserCmd {
	/**
	 * *******惩罚返回******
	 */
	const PARA_PUNISH_RETURN_GMTOOL   = 23;
	public  $zone; 		//game<<16+zoneid
	public  $charid;    //
	public  $username;  //
	public  $gmName; 	//gmName[MAX_NAMESIZE+1];
	public  $operation; //word
	public  $ret;		//word
	public function __construct() {
		parent::__construct();
	}
	public static function getformat() {
		return  "CbyCmd/CbyParam/Itime/Itime2/Izone/Icharid/a33username/a33gmName/voperation/Cret";
	}
}
 
class RedeemReturn_GmTool extends GmToolUserCmd{
	const  PARA_REDEEM_RETURN_GMTOOL = 11;
	public $zone;
	public $name;
	public $gmName;
	public $ret;//是否成功，1成功
	public function __construct() { 
		parent::__construct ();
	}
};
class UserOnline_GmTool extends GmToolUserCmd {
	/**
	 * *******玩家是否在线参数********
	 */
	const PARA_USER_ONLINE_GMTOOL = 12;
	protected $zone;
	protected $name;
	protected $gmName;
	protected $ret; // 0:不在 1:在
	public function __construct($z,$name,$gmName,$ret) {
		$this->byParam = self::PARA_USER_ONLINE_GMTOOL;
		parent::__construct ();
		$this->zone = pack("v",$z->id).pack("v",$z->name);
		$this->name = pack("a".strlen($name)."@33",$name);
		$this->gmName = pack("a".strlen($gmName)."@33",$gmName);
		$this->ret = pack("C",$ret);
	}
}
class Importance_Broadcast_GmTool extends GmToolUserCmd {
	/**
	 * *******重要公告********************
	 */
	const PARA_IMPORTANCE_BROADCAST_GMTOOL = 20;
	protected $zone;
	protected $content;
	protected $issueTime;
	protected $GM;
	protected $id;
	protected $effectTime;
	protected $interval;		//DWORD播放间隔,分,0无循环
	protected $showpos;			//WORD显示位置
	public function __construct($z,$content,$GM,$id,$effectTime,$issueTime=0,$intval=0,$spos=0) {	
		//log1("gamesocket-".date("Y-m-d"),"C->S...PARA_IMPORTANCE_BROADCAST_GMTOOL...".$z."|".$content."|".$GM."|".$id."|".$effectTime."|".$issueTime);
		log1("xxx.txt","C->S...PARA_IMPORTANCE_BROADCAST_GMTOOL...".$z."|".$content."|".$GM."|".$id."|".$effectTime."|".$issueTime.",intval=".$intval.",spos=".$spos);
		$this->byParam = self::PARA_IMPORTANCE_BROADCAST_GMTOOL;
		parent::__construct ();
		 
		$this->zone = pack("I",$z);
		$this->content = pack("a".strlen($content)."@256",$content);
		$this->issueTime = pack("I",$issueTime);
		$this->GM = pack("a".strlen($GM)."@33",$GM);
		$this->id = pack('I',$id);
		$this->effectTime = pack("I",$effectTime);
		$this->interval = pack("I",$intval);
		$this->showpos = pack("v",$spos);
	}
	public function getCmd(){
		$data =  $this->getBasicInstructs();
		$data =  $data.$this->zone.$this->content.$this->issueTime.$this->GM.$this->id.$this->effectTime;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
		
}
class Group_redeem_GmTool extends GmToolUserCmd{
	// GM群发补偿功能
	const  PARA_GROUP_REDEEM_GMTOOL = 26;
	const	ULS_MAX_LEN = 1024;
	const MAX_REDEEM_LEN = 256;
	protected $zone;
	protected $groupType;			// 群类型 0全体 >0为某国
	protected $groupValue;			// 群类型 子类型,职业 0全体 >0为某职业
	protected $minLevel;			// 玩家最低等级
	protected $maxLevel;			// 玩家最高等级
	protected $isOnline;			// 是否要求在线	0,不要求；1要求
	protected $gmName;				//GM姓名
	protected $tid;  				// 交易流水号
	protected $itemID;				// 补偿礼包的ID
	protected $effectTime;			// 有效时间，从补偿时间开始计算， 多少秒能够领取
	protected $giftnum;				//数量
	protected $sept;				//军团
	protected $uls;					//用户ID列表
	protected $objls;				//多种道具
	public function __construct($z,$groupType,$groupValue,$minLevel,$maxLevel,$isOnline,$gmName,$tid,$itemID,$effectTime,$giftnum,$sept=0,$ls="",$objls=""){
		log1("debug".__TODAY,"C->S...PARA_GROUP_REDEEM_GMTOOL...".$z."|".$groupType."|".$groupValue."|".$minLevel."|".$maxLevel."|".$isOnline."|".$gmName."|".$tid."|".$itemID."|".$effectTime."|".$giftnum.",sept=".$sept.",ls=".$ls.",objls=".$objls);
		$this->byParam = self::PARA_GROUP_REDEEM_GMTOOL;
		parent::__construct();
		$gz = getGameZoneBySID($z);
		$this->zone = pack("I",$z);
		$this->groupType = pack("I",$groupType);
		$this->groupValue = pack("v",$groupValue);
		$this->minLevel = pack("v",$minLevel);
		$this->maxLevel = pack("v",$maxLevel);
		$this->isOnline = pack("C",$isOnline);
		$this->gmName = pack("a".strlen($gmName)."@33",$gmName);
		$this->tid = pack("a".strlen($tid)."@33",$tid);
		$this->itemID =  pack("I",$itemID);
		$this->effectTime = pack("I",$effectTime);
		$this->giftnum = pack("I",$giftnum);
		$this->sept = pack("I",$sept);
		$this->uls = pack("a".strlen($ls)."@".self::ULS_MAX_LEN,$ls);
		$this->objls = pack("a".strlen($objls)."@".self::MAX_REDEEM_LEN,$objls);
	}
	public function getCmd(){
		$data =  $this->getBasicInstructs();
		$data =  $data.$this->zone.$this->groupType.$this->groupValue.$this->minLevel.$this->maxLevel.$this->isOnline.$this->gmName.$this->tid.$this->itemID.$this->effectTime.$this->giftnum.$this->sept.$this->uls.$this->objls;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
}
class Group_redeem_Return_GmTool extends GmToolUserCmd{
	// GM群发补偿功能返回
	const PARA_GROUP_REDEEM_RETURN_GMTOOL = 27;
	protected $zone;
	protected $gmName;
	protected $ret; 				//补偿返回码 0 失败， 1成功
	public static function getformat() {
		return  "CbyCmd/CbyParam/Itime/Itime2/Izone/a33gmName/Cret";
	}
}
class ExecCommand_GmTool extends GmToolUserCmd{
	const PARA_EXEC_COMMAND_GMTOOL = 16;
	protected $zone;
	protected $gmName;             //GM名
	protected $cmd;				  //指令64
	public function __construct($zone,$gameName,$cmd){
		log1("gamesocket-".date("Y-m-d"),"C->S...PARA_EXEC_COMMAND_GMTOOL...".$zone."|".$gameName."|".$cmd);
		$this->byParam = self::PARA_EXEC_COMMAND_GMTOOL;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gameName)."@33",$gameName);
		$this->cmd = pack("a".strlen($cmd)."@64",$cmd);
	}
	public function getCmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName.$this->cmd;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//返回日志 
class Log_GmTool extends GmToolUserCmd{
	const PARA_LOG_GMTOOL = 9;
	public $zone;				//区
	public $time;				//时间
	public $charID;				//
	public $accID;				//
	public $gmName;				//GM名字
	public $pos;				//地图名
	public $cmd;				//指令名
	public $content;			//内容
	public $state;				//执行指令后是否成功：0表示失败，1表示成功
	public static function getformat() {
		return  "CbyCmd/CbyParam/Itime/Izone/Itime/Itime2/IcharID/IaccID/a33gmName/a33pos/a33cmd/a64content/Cstate";
	}
};
//查看角色幸运值
class Req_User_Lucky_GmTool extends GmToolUserCmd{
	const REQ_USER_LUCKY_GMTOOL = 28;
	protected $zone;
	protected $gmName;		//GM姓名
	protected $userName;	//角色姓名
	protected $accid;			//角色账号ID
	protected $charid;			//角色ID
	public function __construct($zone,$gameName,$userName,$accid,$charid){
		log1("gamesocket-".date("Y-m-d"),"C->S...Req_User_Lucky_GmTool...".$zone."|".$gameName."|".gbktoutf8($userName)."|".$accid."|".$charid);
		$this->byParam = self::REQ_USER_LUCKY_GMTOOL;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gameName)."@33",$gameName);
		$this->userName = pack("a".strlen($userName)."@33",$userName);
		$this->accid = pack("I",$accid);
		$this->charid = pack("I",$charid);
	}
	public function getCmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName.$this->userName.$this->accid.$this->charid;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//查看返回
class Ret_User_Lucky_GmTool extends GmToolUserCmd{
	const RET_USER_LUCKY_GMTOOL = 29;
	protected $zone;
	protected $gmName;      	//GM姓名
	protected $userName;		//角色名
	protected $ret;				//0角色不在线，无法查找, 1成功返回	
	public static function getformat() {
		$format = "CbyCmd/CbyParam/Itime/Izone/a33gmName/a33userName/Cret";
		for($i=0;$i<5;$i++)		//返回的5个幸运值信息，0宠物升品值，1宠物进化值，2翅膀进化值，3五行修炼值,4星辰修炼
		
			$format .="/vnowLucky{$i}/vnowNoBindTimes{$i}/vnowBindTimes{$i}";//当前幸运值,非绑次数,绑定次数
		return $format;
	}
};
//修改某项幸运值
class ChangeUserOneLucky_GmTool extends GmToolUserCmd{
	const CHANGE_USER_ONE_LUCKY_GMTOOL = 30;
	protected $zone;
	protected $gmName;    					//GM姓名
	protected $userName;  					//角色名
	protected $accid;						//账号ID
	protected $charid;						//角色ID
	protected $whichOne;					//修改的是哪个 0宠物升品值，1宠物进化值，2翅膀进化值，3五行修炼值
	protected $lucky;						//幸运值
	protected $nowTimes;					//修改非绑的值到多少
	protected $nowBindTimes;				//修改绑定的值到多少
	public function __construct($zone,$gameName,$userName,$accid,$charid,$whichOne,$lucky,$nowTimes,$nowBindTimes){
		log1("gamesocket-".date("Y-m-d"),"C->S...CHANGE_USER_ONE_LUCKY_GMTOOL...".$zone."|".$gameName."|".$userName."|".$accid."|".$charid."|".$whichOne."|".$lucky."|".$nowTimes."|".$nowBindTimes);
		$this->byParam = self::CHANGE_USER_ONE_LUCKY_GMTOOL;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gameName)."@33",$gameName);
		$this->userName = pack("a".strlen($userName)."@33",$userName);
		$this->accid = pack("I",$accid);
		$this->charid = pack("I",$charid);
		$this->whichOne = pack("C",$whichOne);
		$this->lucky = pack("v",$lucky);
		$this->nowTimes = pack("v",$nowTimes);
		$this->nowBindTimes = pack("v",$nowBindTimes);
	}
	public function getcmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName.$this->userName.$this->accid.$this->charid.$this->whichOne.$this->lucky.$this->nowTimes.$this->nowBindTimes;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//返回修改是否成功
class ChangeUserOneLucky_Return_GmTool extends	GmToolUserCmd{
	const CHANGE_USER_ONE_LUCKY_RETURN_GMTOOL = 31;
	protected $zone;
	protected $gmName;    					//GM姓名
	protected $userName;  					//角色名
	protected $ret;							//0不成功，1成功
	public static function getformat() {
		$format = "CbyCmd/CbyParam/Itime/Izone/a33gmName/a33userName/Cret";
		return $format;
	}
};
//请求某区及时在线人数， 整点要读取数据库
class Req_OnlineNum_GmTool extends GmToolUserCmd{
	const PARA_REQ_ONLINENUM_GMTOOL = 24;
	protected $zone;				//zone.id=0时，请求所有区
	protected $gmName;
	public function __construct($zone,$gmName){
		log1("gamesocket-".date("Y-m-d"),"C->S...PARA_REQ_ONLINENUM_GMTOOL...".$zone."|".$gmName);
		$this->byParam = self::PARA_REQ_ONLINENUM_GMTOOL;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gmName)."@33",$gmName);
	}
	public function getcmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//返回某区在线人数
class RefreshOnlineNum_GmTool extends  GmToolUserCmd{
	const PARA_REFRESH_ONLINE_NUM_GMTOOL = 25;
	protected $zone;
	protected $onlineNum;//WORD
	protected $gmName;
	public static function getformat() {
		$format = "CbyCmd/CbyParam/Itime/Itime2/Izone/vonlineNum/a33gmName";
		return $format;
	}
};
//请求在线等级分布
class stRequestOnlineLVGmUserCmd extends GmToolUserCmd{
	const REQUEST_ONLINE_LV_GM_USERCMD_PARA = 29;
	protected $zone;				//zone.id=0时，请求所有区,zoneid+game<<16
	protected $gmName;
	public function __construct($zone,$gmName){
		log1("gamesocket",date("Y-m-d")."C->S...REQUEST_ONLINE_LV_GM_USERCMD_PARA...".$zone."|".$gmName);
		$this->byParam = self::REQUEST_ONLINE_LV_GM_USERCMD_PARA;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gmName)."@33",$gmName);
	}
	public function getcmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//响应在线等级分布
class stReturnOnlineLVGmUserCmd extends  GmToolUserCmd{
	const RETURN_ONLINE_LV_GM_USERCMD_PARA = 30;
	protected $gmName;
	protected $size;//WORD
	//等级和数量连在一起构成结构体
	protected $lv; // DWORD
	protected $num; // DWORD
};
//请求上传配置文件
class st_ReqUploadConfGmTool extends GmToolUserCmd{
	const REQ_UPLOAD_CONF_GMTOOL = 31;
	protected $zone;			//GameZone_t zone;
	protected $gmName;
	protected $path;			//char path[64];				//文件名
	protected $data;			//char data[32*1024];			//数据
	public function __construct($zone,$path,$data,$gmName){
		log1("debug".__TODAY,"REQ_UPLOAD_CONF_GMTOOL,zone=".$zone.",path=".$path.",gmName=".$gmName);
		$this->byParam = self::REQ_UPLOAD_CONF_GMTOOL;
		parent::__construct();
		$this->zone = pack("I",$zone);
		$this->gmName = pack("a".strlen($gmName)."@32",$gmName);
		$this->path = pack("a".strlen($path)."@64",$path);
		$this->data = pack("a".strlen($data)."@".(32*1024),$data);
	}
	public function getcmd(){
		$data =  $this->getBasicInstructs();
		$data = $data.$this->zone.$this->gmName.$this->path.$this->data;
		$data =  $this->getCompressInstructs($data);//压缩更不能忘
		return $data;
	}
};
//响应上传配置文件
class st_RspUploadConfGmTool extends  GmToolUserCmd{
	const RSP_UPLOAD_CONF_GMTOOL = 32;
	protected $ret;	//结果:0成功/1失败
	protected $gmName;
	public static function getformat() {
		$format = "CbyCmd/CbyParam/Itime/Itime2/Cret/a32gmName";
		return $format;
	}
};