<?php
require_once("BaseLogic.class.php");
class Partion extends BaseLogic {
	function __construct(){
		$this->tabName = TAB_PREFIX."partion";
		$this->primaryKey='id';
		$this->fieldList=array("id","platform", "zoneid","name", "status", "mid","usetime","host","lhost","user","pass","db","port");
	}
	function validateForm($partion=1){
		$result=true;
		if(!Validate::required($_POST['platform'])) {
			$this->messList[] = "平台不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['zoneid'])) {
			$this->messList[] = "分区编号不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['name'])) {
			$this->messList[] = "分区名称不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['usetime'])) {
			$this->messList[] = "最近开服时间不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['pass'])) {
			$this->messList[] = "数据库密码不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['host'])) {
			$this->messList[] = "主机不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['lhost'])) {
			$this->messList[] = "主机不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['user'])) {
			$this->messList[] = "数据库用户不能为空.";
			$result=false;
		}
		if(!Validate::required($_POST['db'])) {
			$this->messList[] = "数据库名不能为空.";
			$result=false;
		}
		if($partion){
			if($this->isPlatformZoneIdExists($_POST['platform'],$_POST["zone"])) {
				$this->messList[] = "该区已经存在.";
				$result=false;
			}
		}
		return  $result;
	}
	//获取指定平台所有大区数据
	function getPartionsByPlatform($platform=null,$mid=null,$filterColumn=null){
		if(isset($platform)){
			$platform = " and p.platform='{$platform}'";
		}else
			$platform = "";
		if(isset($mid)){
			$mid = " and m.id={$mid}";
		}else
			$mid = "";
		$sql  =" select m.id as mid,p.id,p.platform,p.zoneid,p.name,m.ip3,p.host,p.lhost,p.db,p.user,p.pass,p.port,m.port port_on";
		$sql .=" from {$this->tabName} p inner join  ".TAB_PREFIX."machine m ";
		$sql .=" on m.id=p.mid and m.status=1 and p.status=1 {$platform} {$mid} order by p.zoneid desc ";
		log1("debug".__TODAY,"[分区]取分区信息,sql=".$sql);
		$result=MyDB::getInstance()->query($sql);		
		while($row=$result->fetch_assoc()){
			$row['usetime'] = date("Y-m-d H:i",$row['usetime']);
			if(!empty($filterColumn)){
				$keys = array_keys($row);
				foreach($keys as $v)
					if(!in_array($v, $filterColumn))
						unset($row[$v]);
			}
			$data[]=$row;
		}
		return $data;
	}
	//根据平台ID获取分区数据
	function getPartionByid($id) {
		$sql = "SELECT * FROM {$this->tabName} WHERE id=$id";
		$result=MyDB::getInstance()->query($sql);		
		while($result && $row=$result->fetch_assoc()){
			$data[]=$row;
		}
		return $data;
	}
	//获取指定分区的分区信息+机器信息
	function getPartionMachineByid($id=null){
		if(isset($id)){
			$ids =" and p.id={$id}";
		}else
			$ids ="";
		$sql  = " select m.id mid ,m.port,p.id,p.platform,p.zoneid,p.name,m.ip3,p.host,p.lhost,p.db,p.user,p.pass,p.usetime,p.port port0 ";
		$sql .=" from {$this->tabName} p inner join  ".TAB_PREFIX."machine m ";
		$sql .=" on m.id=p.mid and m.status=1 and p.status=1 {$ids} order by p.zoneid desc ";
		$result=MyDB::getInstance()->query($sql);
		while($row=$result->fetch_assoc()){
			$row['usetime'] = date("Y-m-d H:i",$row['usetime']);
			$data[]=$row;
		}
		return $data;
	}
	//平台和分区号唯一确定分区
	function  isPlatformZoneIdExists($platform,$zoneId){
		$result=MyDB::getInstance()->query("SELECT * FROM {$this->tabName} WHERE platform='{$platform}' zoneId ='{$zoneId}'");
		if($result->num_rows>0){
			return 1;
		}else{
			return 0;
		}
	}
	//根据平台自动生成区号
	function autoGenNextZoneId($platform){
		$sql = "SELECT zoneid FROM {$this->tabName} where 1=1 and platform ='{$platform}' ORDER BY zoneid desc LIMIT 0, 1";
		$result=MyDB::getInstance()->query($sql);
		if($row=$result->fetch_assoc()){
			$data = $row;
		}
		if(!empty($data)){
			$data = intval($data['zoneid']);
		}
		$data += 1;
		return $data;
	}
	//判断平台的分区是否存在
	function isPartionExists($platform,$zoneId=""){
		$result=MyDB::getInstance()->query("SELECT zone FROM {$this->tabName} WHERE platform='{$platform}' zoneId ='{$zoneId}'");
		if($result->num_rows>0){
			return 1;
		}else{
			return 0;
		}
	}
	//添加分区
	function PartionAdd($post) {	
		if($this->add($post)){
			$this->messList[] = "添加分区成功.";
			return true;
		}else{
			$this->messList[] = "添加分区失败.";
			return false;
		}
	}
	//删除分区
	function delPartion($id){
		if($this->del($id)){
			$this->messList[] = "删除分区成功.";
			return true;
		}else{
			$this->messList[] = "删除分区失败.";
			return false;
		}
	}
	//获取平台分区名
	function getPartionByzid($zid=null){
		if(isset($zid)){
			$where = "where zoneid = $zid";
		}else{
			return false;
		}
		$result=MyDB::getInstance()->query("SELECT name FROM {$this->tabName} $where");
		while($row=$result->fetch_assoc()){
			return $row;
		}
	}
	//获取平台总分区数目
	function getRowTotal($platform=null){
		if(isset($platform))
			$platform =" and  platform='{$platform}'";
		else 
			$platform ="";
		$result=MyDB::getInstance()->query("SELECT * FROM {$this->tabName} where 1=1 $platform");
		return $result->num_rows;	
	}
	//修改分区
	function modPartion($postList,$type=1){
		if($this->mod($postList)){
			$this->messList[] = "修改成功.";
			return 1;
		}else{
			$this->messList[] = "修改失败.";
			return 0;
		}
	}
	//根据平台取所有分区
	function getAllPartionsByPlatform($platform){
		$sql = "SELECT * FROM {$this->tabName} WHERE platform='{$platform}'";
		$result=MyDB::getInstance()->query($sql);
		while($row=$result->fetch_assoc()){
			$data[]=$row;
		}
		return $data;
	}
	//取平台所有大区，根据平台和分区号唯一确定
	function getPartionsByPlatformZoneid($platform=null,$zoneid=null){
		if(isset($platform)){
			$platform = " and p.platform='{$platform}'";
		}else
			$platform = "";
		if(isset($mid)){
			$zoneid = " and p.zoneid={$zoneid}";
		}else
			$zoneid = "";
		$sql  =" select m.id,m.ip3,m.port,p.id,p.platform,p.zoneid,p.name,p.host,p.lhost,p.db,p.user,p.pass,p.usetime ";
		$sql .=" from {$this->tabName} p inner join  ".TAB_PREFIX."machine m ";
		$sql .=" on m.id=p.mid and m.status=1 and p.status=1 {$platform} {$zoneid} order by p.zoneid desc ";
		$result=MyDB::getInstance()->query($sql);
		while($row=$result->fetch_assoc()){
			$row['usetime'] = date("Y-m-d H:i",$row['usetime']);
			$data[]=$row;
		}
		return $data;
	}
	//获取所有已禁用的分区
	function getAllDisabledPartions(){
		$sql  =" select m.ip3,p.id,p.zoneid,p.name,p.host,p.db,p.user,p.pass,p.usetime ";
		$sql .=" from {$this->tabName} p inner join  ".TAB_PREFIX."machine m ";
		$sql .=" on m.id=p.mid1 and m.status=1 and p.status=0 order by p.zoneid desc ";	
		$result=MyDB::getInstance()->query($sql);
		while($row=$result->fetch_assoc()){
			$row['usetime'] = date("Y-m-d H:i",$row['usetime']);
			$data[]=$row;
		}
		return $data;
	}
	//从session中缓存所有已禁用的分区
	function getAllDisabledPartionFromSession(){
		if(empty($_SESSION['allDisabledPartionInfo'])){
			$partionData = $this->getAllPartions();
			$_SESSION['allDisabledPartionInfo'] = serialize($partionData );
		}else{
			$partionData = unserialize($_SESSION['allDisabledPartionInfo'] );
		}
		return $partionData;
	}
	function getPartionFromSession(){
		if(empty($_SESSION['partionInfo'])){
			$partionData = $this->getPartions();
			$_SESSION['partionInfo'] = serialize($partionData );
		}else{
			$partionData = unserialize($_SESSION['partionInfo'] );
		}
		return $partionData;
	}
	static function getRealOnlineToal($sid){
		$partionObj =new Partion();
		$allPartion = $partionObj->getPartionFromSession();
		$ret = GameSocket::getInstance()->connectSocket(INFORDB_HOST,INFORDB_PORT);
		if(!$ret)
			return 0;
		$rqLogin = new  RequestLoginGmUserCmd("Administrator","Administrator");
		$cmd = $rqLogin->getCmd();
		$retLogin = GameSocket::getInstance()->sendCmd1($cmd);
		if(!$retLogin)
			return 0;
		$retRead = GameSocket::getInstance()->readCmd1();
		if(!$retRead)
			return 0;
		if($sid==0)
			$z = $sid;
		else
			$z = getSID(8, $sid);
		if(GameSocket::getInstance()->gmPri()!=1)
			return 0;
		$ret = new Req_OnlineNum_GmTool($z, "Administrator");
		$cmd = $ret->getcmd();
		$ret = GameSocket::getInstance()->sendCmd1($cmd);
		if(!$ret)
			return 0;
		$retR = GameSocket::getInstance()->readCmd1();
		if(!$retR){
			return 0;
		}
		foreach($allPartion as $v){
			if($sid==0){
				if(isset($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.getSID(GAMEID,$v['zone'])])){
					$row[$v['zone']] = intval($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.getSID(GAMEID,$v['zone'])]);
					unset($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.$zone]);
				}
			}elseif($sid == $v['zone']){
				if( isset($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.getSID(GAMEID,$v['zone'])]) ){
					$row[$v['zone']] = intval($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.getSID(GAMEID,$v['zone'])]);
					unset($_SESSION['CMD'.RefreshOnlineNum_GmTool::PARA_REFRESH_ONLINE_NUM_GMTOOL.getSID(GAMEID,$v['zone'])]);
				}
				break;
			}
		}
		if(!empty($row)) ksort($row);
		return $row;
	}
}
?>
