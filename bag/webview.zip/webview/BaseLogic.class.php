<?php
	class BaseLogic  {
		protected $tabName;		//表的名称
		protected $fieldList;
		protected $messList;
		protected $primaryKey = 'id';
		function __construct(){}
		function getItemList($where ="1=1",$orderby="id desc",$limit="0,10",$field=false){			
			if(!empty($where)){
				$where = " where ".$where;
			}
			if(!empty($orderby)){
				$orderby = " order by ".$orderby;
			}
			if(!empty($limit)){
				$limit = " limit ".$limit;
			}
			if(!$field)
				$field = "*";			
			$sql = "SELECT {$field} FROM `".$this->tabName."`";
			$sql .= $where;
			$sql .= $orderby;
			$sql .= $limit;			
			$result=MyDB::getInstance()->query($sql);		
			while($result && $aRow = $result->fetch_assoc() ){				
				$data[]= $aRow;
			}	
			return $data;			
		}
		function getItemList_1($where ="1=1",$orderby="id desc",$limit="0,20"){				
			if(!empty($where)){
				$where = " where ".$where;
			}
			if(!empty($orderby)){
				$orderby = " order by ".$orderby;
			}
			if(!empty($limit)){
				$limit = " limit ".$limit;
			}
			$sql = "SELECT * FROM `".$this->tabName."`";			
			$sql .= $where;			
			$sql .= $orderby;
			$sql .= $limit.";";
			$result=MyDB::getInstance()->query($sql);				
			while($result && $aRow = $result->fetch_assoc() ){
				$data[]= $aRow;
			}
			$sqlcount = "SELECT count(*) num FROM `".$this->tabName."`" .$where;			 
			$result=MyDB::getInstance()->query($sqlcount);
			if($result && $aRow = $result->fetch_assoc() ){
				$total= $aRow['num'];
			}
			$ret = array('total'=>$total,'data'=>$data);
			return $ret;
		}
		//==========================================
		// 函数: add($postList)
		// 功能: 添加
		// 参数: $postList 提交的变量列表
		// 返回: 刚插入的自增ID
		//==========================================
		function add($postList) {
			$fieldList='';
			$value='';
			foreach ($postList as $k=>$v) {
				if(in_array($k, $this->fieldList)){
					$fieldList.= "`".$k."`,";
					if (!get_magic_quotes_gpc())
						$value .= "'".addslashes($v)."',";
					else
						$value .= "'".$v."',";
				}
			}		
			$fieldList=rtrim($fieldList, ",");
			$value=rtrim($value, ",");
			$sql = "INSERT INTO {$this->tabName} (".$fieldList.") VALUES(".$value.")";
			log1('mysql',$sql);
			$result=MyDB::getInstance()->query($sql);
			if($result && MyDB::getInstance()->affected_rows >0 ){
				if(MyDB::getInstance()->insert_id){
					return MyDB::getInstance()->insert_id;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
		/**
		 * 替换函数
		 * @param array $postList
		 * @return true or false
		 */
		function replace($postList) {
			$fieldList='';
			$value='';
			foreach ($postList as $k=>$v) {
				if(in_array($k, $this->fieldList)){
					$fieldList.=$k.",";
					if (!get_magic_quotes_gpc())
						$value .= "'".addslashes($v)."',";
					else
						$value .= "'".$v."',";
				}
			}
			$fieldList=rtrim($fieldList, ",");
			$value=rtrim($value, ",");
			$sql = "REPLACE INTO {$this->tabName} (".$fieldList.") VALUES(".$value.")";
			$result=MyDB::getInstance()->query($sql);
			if($result && MyDB::getInstance()->affected_rows >0 ) 
				if(MyDB::getInstance()->insert_id){
					return MyDB::getInstance()->insert_id;
				}else{
					return true;
				}			
			else
				return false;
		}
		//==========================================
		// 函数: mod($postList)
		// 功能: 修改表数据
		// 参数: $postList 提交的变量列表
		//==========================================
		function mod($postList,$notid=false) {
			$id=$postList[$this->primaryKey];
			unset($postList[$this->primaryKey]);
			$value='';
			foreach ($postList as $k=>$v) {
				if(in_array($k, $this->fieldList)){
					if (!get_magic_quotes_gpc())
						$value .= "`".$k."` = '".addslashes($v)."',";
					else
						$value .= "`".$k."` = '".$v."',";
				}
			}
			$value=rtrim($value, ",");
			if($notid){
				$sql = "UPDATE {$this->tabName} SET {$value} WHERE {$this->primaryKey}='{$id}'";
			}else{
				$sql = "UPDATE {$this->tabName} SET {$value} WHERE {$this->primaryKey}={$id}";
			}
			log1('xxx.txt',$sql);
			MyDB::getInstance()->query($sql);
			return MyDB::getInstance()->affected_rows;
		}
		//==========================================
		// 函数: del($id)
		// 功能: 删除
		// 参数: $id 编号或ID列表数组
		// 返回: 0 失败 成功为删除的记录数
		//==========================================
		function del($id) {
			if(is_array($id))
				$tmp = "IN (" . join(",", $id) . ")";
			else 
				$tmp = "= $id";
			$sql = "DELETE FROM {$this->tabName} WHERE {$this->primaryKey} " . $tmp ;
			MyDB::getInstance()->query($sql);	
			return MyDB::getInstance()->affected_rows;
		}
		function get($id) {
			$sql = "SELECT * FROM {$this->tabName} WHERE {$this->primaryKey} ={$id}";
			$result=MyDB::getInstance()->query($sql);
			if($result && $result->num_rows ==1){
				return $result->fetch_assoc();
			}else{
				return false;
			}
		}
		function getMessList(){
			$message="";
			if(!empty($this->messList)){
				foreach($this->messList as $value){
					$message.=$value."  ";
				}
			}else{
				return '';
			}
			return array_pop($this->messList); 	
		}
	    public function fetch_one($result){	   		
	        return $result->fetch_assoc();        
	    }
	    public function fetch_array($result){
	        while ($row = $result->fetch_assoc()){
	            $rs[] = $row;
	        }
	        return $rs;
	    }
	    /**
	     * 函数在指定的预定义字符前添加反斜杠。换句话说就是字符转义，屏蔽掉特定字符
	     * @param string or array $string
	     * @param int $force
	     * @param bool $strip
	     * @return array or string
	     */
	    function string_addslashes($string, $force = 0, $strip = FALSE){
	    	!defined('MAGIC_QUOTES_GPC') && define('MAGIC_QUOTES_GPC', get_magic_quotes_gpc());
	    	if(!MAGIC_QUOTES_GPC || $force) {
	    		if(is_array($string)) {
	    			foreach($string as $key => $val) {
	    				$string[$key] =$this->string_addslashes($val, $force, $strip);
	    			}
	    		} else {
	    			$string = addslashes($strip ? stripslashes($string) : $string);
	    		}
	    	}
	    	return $string;
	    }
	}
?>
