<?php
//api�ӿ�,zl,2015-05-26
require_once("c_step.php");
@define("FILE_ROOT",ereg_replace("[/\\]{1,}",'/',dirname(__FILE__)).'/');
$m_act = isset($_GET["act"])?$_GET["act"]:"";
$m_eid = intval(isset($_GET["eid"])?$_GET["eid"]:0);
$m_sid = intval(isset($_GET["sid"])?$_GET["sid"]:0);
$m_uid = intval(isset($_GET["uid"])?$_GET["uid"]:0);
$m_des = intval(isset($_GET["des"])?$_GET["des"]:0);

//log1("score".date("Ymd"),"�ID��".$m_eid." | ������".$m_act." | ������".$m_sid." | �˺�ID��".$m_uid);

$o = new c_step;
if("state"==$m_act){	//״̬
	$ret = $o->state($m_eid,$m_sid,$m_uid);
	echo json_encode($ret);
}
else if("get"==$m_act){	//�콱
	$ret = $o->get($m_eid,$m_sid,$m_uid,$m_des);
	echo json_encode($ret);	
}
function log1($f,$c){
	$d = FILE_ROOT."log"."/";
	if(!$fp = @fopen($d.$f,"a+")){
		echo "can't open $d.$f";
	}else{
		fwrite($fp, date("Y-m-d H:i:s")."---->>".$c."\r\n");
	}
	fclose($fp);
}
?>

