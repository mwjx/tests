<?php
//���ȹ�����,zl,2015-05-27
//require_once("conf/event.inc.php");
date_default_timezone_set('PRC');
require_once("all.inc.php");
require_once("GameSocket.class.php");
require_once("GameRole.class.php");
require_once("Partion.class.php");
class c_step
{
	var $osql = null;
	var $isql = null;
	var $mp_des = array();		//Ŀ���=>[{���,�����,��������}]
	var $mp_scoretp = array();	//���=>[��������]
	var $mp_evttp = array();	//���=>�����
	var $m_arrevt= array();
	var $m_arrreward = array();

	function __construct()
	{
		$this->load();

		$this->osql = null; //���ݿ����
		$this->isql = null; //���ݿ����
		
		$inf = array();
		$inf["ip"] = "localhost";
		$inf["user"] = "root";
		$inf["pass"] = "111111";
		$inf["db"] = "webview";
		$inf["port"] = "3306";

		$ret = $this->connect($inf);

		$inf0 = array();
		$inf0["ip"] = "localhost";
		$inf0["user"] = "root";
		$inf0["pass"] = "111111";
		$inf0["db"] = "gitgm";
		$inf0["port"] = "3306";

		$this->connect_db($inf0);
}
	function connect($inf=null)
	{
		//�������ݿ�
		//����:inf���ݿ���Ϣ
		//����:true/false
		//����ƽ̨���ݿ�
		$host = $inf["ip"];
		$user = $inf["user"];
		$pswd = $inf["pass"];
		$db = $inf["db"];
		$port = $inf["port"];
		//exit("[�������]����ƽ̨���ݿ�".$host."|".$user."|".$pswd."|".$db);
		//log1("debug".__TODAY,"[�������]����ƽ̨���ݿ�".$host."|".$user."|".$pswd."|".$db);
		$this->osql =new mysqli($host, $user, $pswd, $db,$port) ;
		if(mysqli_connect_errno()) {
			//log1 ("err".__TODAY,"����ʧ��".$host."|".$user."|".$pswd."|".$db."��ԭ��Ϊ��".mysqli_connect_error());
			return false;
		}
		return true;
	}
	function connect_db($inf0)
	{
		//���ӱ������ݿ�
		$host = $inf0["ip"];
		$user = $inf0["user"];
		$pswd = $inf0["pass"];
		$db = $inf0["db"];
		$port = $inf0["port"];
		$this->isql =new mysqli($host, $user, $pswd, $db,$port) ;
		if(mysqli_connect_errno()) {
			return false;
		}
		return true;
	}

	function load()
	{
		global $event_js;
		global $reward_js;
		$this->m_arrevt = json_decode($event_js);
		$this->m_arrreward = json_decode($reward_js);
		$ret = &$this->mp_des;
		for($i=0;$i<count($this->m_arrevt);++$i){	//�������
			$o = $this->m_arrevt[$i];
			$s = strtotime($o->start);
			$e = strtotime($o->end);
			$n = time();
			$eid = $o->id;
			$etp = $o->tp;
			if($n<$s || $n>$e){continue;}
			if(1!=$o->tp){continue;}		//��ʱֻ����������
			if(!isset($this->mp_evttp[$eid])){$this->mp_evttp[$eid]=$etp;}
			$c = $o->conf;
			for($j=0;$j<count($c);++$j){	//��������
				$ae = $c[$j]->evtls;
				$t = $c[$j]->tp;
				$gift 	= $c[$j]->gift;
				//����Ŀ��
				for($k=0;$k<count($ae);++$k){
					$idx = $ae[$k];
					if(!isset($ret[$idx])){$ret[$idx] = array();}
					$ret[$idx][] = array("eid"=>$eid,"etp"=>$etp,"stp"=>$t);
				}
				if(!isset($this->mp_scoretp[$eid])){$this->mp_scoretp[$eid]=array();}
				$this->mp_scoretp[$eid][] = $t;
				if(!isset($this->mp_gifts[$eid])){$this->mp_gifts[$eid]=array();}
				if(empty($gift) || count($gift) < 1){continue;}
				foreach($gift as $key => $val){
					$this->mp_gifts[$t][$val->val] = ($t-1)*100+$key;
				}
			}
		}
	}

	function save(&$oe)
	{
		//��¼Ŀ��
		//var_dump($oe);
		$e = $oe["evt"];
		if(!isset($this->mp_des[$e])){return;}
		$arg = $oe["arg"];
		$sid = $arg["sid"];
		$uid = $arg["uid"];

	//	var_dump($arg["sid"]);
	//	exit();
		//$tp = $this->mp_des[$e]->etp;
		$ls = &$this->mp_des[$e];
		for($i=0;$i<count($ls);++$i){
			$eid = $ls[$i]["eid"];
			$etp = $ls[$i]["etp"];
			$stp = $ls[$i]["stp"];
			//var_dump($ls[$i]["eid"]);
			if(1!=$etp){continue;}
			$this->save_score($sid,$uid,$eid,$stp);
		}
		//var_dump($this->mp_des[$e]);
	}
	function save_score($sid,$uid,$eid,$tp)
	{
		//���������
		//echo "sid=".$sid.",uid=".$uid.",eid=".$eid.",tp=".$tp;
		$val = $this->get_score($sid,$uid,$eid,$tp);
		if($val<0){return;}
		$this->up_score($sid,$uid,$eid,$tp,$val+1);
		//var_dump($val);
	}

	function state($eid,$sid,$uid)
	{
		//��ѯ����
		//����:
		//����:json�ṹ
		//��ѯ����͵���Ϣ
		$ret = array();
		$ret["code"] = 1;	//�������
		if(!isset($this->mp_evttp[$eid])){return $ret;}
		$etp = $this->mp_evttp[$eid];
		$ret["code"] = 2;	//������Ч
		if(1!=$etp){return $ret;}
		//ת����Ӧ��ѯ
		return $this->state_score($eid,$sid,$uid);

	//	$ret["code"] = 200;
	//	$ret["ls"] = array();
	//	$ret["ls"][] = array("tp"=>1,"val"=>2);
	//	$ret["ls"][] = array("tp"=>2,"val"=>30);
	//	$ret["edls"] = array();
	//	$ret["edls"][] = 0;
	//	$ret["edls"][] = 100;
	//	return $ret;
	}
	function state_score($eid,$sid,$uid)
	{
		//���ֻ����
		//����:
		//����:json�ṹ
		$ret = array();
		//�����
		$ret["code"] = 10;		//�޻�������
		if(!isset($this->mp_scoretp[$eid])){return $ret;}
		$ls = &$this->mp_scoretp[$eid];
		$mp = array();			//��������=>����
		for($i=0;$i<count($ls);++$i){
			$stp = $ls[$i];
			$mp[$stp] = $this->get_score($sid,$uid,$eid,$stp);
		}
		$ret["ls"] = array();
		foreach($mp as $k=>$v){
			$ret["ls"][] = array("tp"=>$k,"val"=>$v);
		}

		//������
		$ret["code"] = 200;
		$ret["edls"] = $this->get_edls($eid,$sid,$uid);

		return $ret;
	}
	function get_edls($eid,$sid,$uid)
	{
		//ȡ�����б�
		//����:
		//����:[no,...]
		$ret = array();

		$tbl = "geted";
		$sql = "select reward from ".$tbl." where sid='".$sid."' and uid='".$uid."' and eid='".$eid."';"; 
		//echo $sql."<br>\n";
		$result=$this->osql->query($sql);
		while($result && $aRow = $result->fetch_assoc()){
			$ret[] = $aRow['reward'];
		}	

		return $ret;
	}
	function get($eid,$sid,$uid,$des)
	{
	//��ȡ����
		$eid = intval($eid);	
		$sid = intval($sid);	
		$uid = intval($uid);	
		$des = intval($des);
		
		if(empty($this->m_arrevt)){return array('code'=>101);die;}	//����ö�ȡ����
		//�жϻ�Ƿ����        
		for ($i=0; $i < count($this->m_arrevt); $i++) { 
			$event = $this->m_arrevt[$i];
			//������� 
			if($event->id != $eid) {return array('code'=>104);die;}
			//�жϻ�Ƿ����	
			if( $this->parseTime($event->start) > time() ||  $this->parseTime($event->end) < time() ){return array('code'=>102);die;}	
		}
		foreach ($this->mp_gifts as $key => $val) {
			foreach ($val as $k => $v) {
				$gifts[] = $v;
			}
		}
		//�ж�����Ƿ����
		if(!in_array($des,$gifts)){return array('code'=>103);die;}	//����������

		//��ȡ�������
		if($des < 100){
			$tp = 1;
		}elseif($des >= 100 &&$des <200){
			$tp = 2;
		}elseif($des >= 200 &&$des <300){
			$tp = 3;
		}

		//�ж�Ŀ�꽱���Ƿ���ȡ
		$sqlg = "SELECT reward FROM geted ";
		$sqlg .="WHERE sid = ".$sid." and uid = ".$uid." and eid = ".$eid." and reward = ".$des;
		$result2 = $this->osql->query($sqlg);
		while($result2 && $aRow = $result2->fetch_assoc()){
			return array('code'=>105);die;		//�������
		}

		$sqlv = "SELECT val FROM score ";
		$sqlv .="WHERE sid = ".$sid." and uid = ".$uid." and eid = ".$eid." and tp = ".$tp;
		$result1 = $this->osql->query($sqlv);
		while($result1 && $aRow = $result1->fetch_assoc()){
			$value = $aRow['val'];
		}
		//Ŀ������Ƿ������ȡ����
		foreach ($this->mp_gifts as $key => $val) {
			if($key == $tp){
				foreach ($val as $k => $v) {
					if($v == $des){
						if($value < $k){return array('code'=>106);die;}	//���ֲ���
					}
				}
			}
		}
		//���ͽ�������¼geted
		//��ѯ��ɫID
		$partionRow = $this->getPartionByzid($sid);
		$role = new GameRole($partionRow['host'], $partionRow['user'], $partionRow['pass'], $partionRow['db'],$partionRow['port']);
		$chardes = $role->getCharidByAccid("ACCID = {$uid}");
		$charid = $chardes['CHARID'];
		$name = $chardes['NAME'];
		// $name = $chardes['NAME'];
		$gmName = $this->gbktoutf8('Administrator');
		// $gmpswd = $this->g_md16('49ba59abbe56e057');
		$gmpswd = '49ba59abbe56e057';
		$zoneid = $this->getSID(54, $sid);
		//��ȡ�������ñ�
		$gid = $des-($tp-1)*100+1;
		for ($i=0; $i < count($this->m_arrreward); $i++) { 
			$id = $this->m_arrreward[$i]->id;
			if($id == $gid){
				$gift = $this->m_arrreward[$i]->ls;
				if(count($gift) == 1){
					$itemID = $gift[0]->tp;	
					$giftnum = $gift[0]->num;
					$objls = '';	
				}elseif(count($gift) > 1){
					$itemID = 0;	
					$giftnum = 1;
					for ($j=0; $j < count($gift); $j++) { 
						$item = $gift[$j]->tp;
						$num = $gift[$j]->num;
						$glist[] = "$item=$num";
					}	
					$objls = implode(',', $glist);
				}
			}
		}
		$tid = time().'1'.$sid.$itemID;
		$redeem_gmtool = new Redeem_GmTool($zoneid, $charid,$name, $gmName, 5, $tid, $itemID,  'date',$giftnum,1440000000,$objls);
		$giftcmd = $redeem_gmtool->getCmd();
		$partionrow = $this->getPartionsByPlatformZoneid($partionRow['platform'],$partionRow['zoneid']);
		if(empty($partionRow)){die;}
		$ret = GameSocket::getInstance()->connectSocket($partionrow[0]['ip3'],$partionrow[0]['port']);
		if(!$ret){die;}
		$rqLogin = new  RequestLoginGmUserCmd($gmName,$gmpswd);
		$cmd = $rqLogin->getCmd();
		$retLogin = GameSocket::getInstance()->sendCmd1($cmd);
		if(!$retLogin){
			die;//('����GM��½����ʧ��');
		}
		$retRead = GameSocket::getInstance()->readCmd1();
		if(!$retRead){
			die;//('socketû�з���GM��Ϣ');
		}
		if(($ret = GameSocket::getInstance()->gmPri())!=1){
			die();
		}
		$ret = GameSocket::getInstance()->sendCmd1($giftcmd);
		if(!$ret)
			die;//('��������ʧ��');
		$retR = GameSocket::getInstance()->readCmd1();
		if(!$retR){
			die;//('����������������ʧ��');
		}
		//Ŀ���������������ݿ�
		$sqlg = "INSERT INTO geted(`sid`,`uid`,`eid`,`reward`) VALUES ";
		$sqlg .="('".$sid."','".$uid."','".$eid."','".$des."');";
		$result = $this->osql->query($sqlg);
		while($result && $aRow = $result2->fetch_assoc()){
			return array('code'=>107);die;		//����ʧ��
		}
		return array('code'=>200);
	}
	//��ȡƽ̨������
	function getPartionByzid($zid=null){
		if(isset($zid)){
			$where = "where zoneid = $zid";
		}else{
			return false;
		}
		$result = $this->isql->query("SELECT * FROM zhsj_partion $where");
		while($row = $result->fetch_assoc()){
			return $row;
		}
	}
	//ȡƽ̨���д���������ƽ̨�ͷ�����Ψһȷ��
	function getPartionsByPlatformZoneid($platform=null,$zoneid=null){
		if(isset($platform)){
			$platform = " and p.platform='{$platform}'";
		}else
			$platform = "";
		if(isset($mid)){
			$zoneid = " and p.zoneid={$zoneid}";
		}else
			$zoneid = "";
		$sql  =" select m.id,m.ip3,m.port,p.id,p.platform,p.zoneid,p.name,p.host,p.lhost,p.db,p.user,p.pass,p.usetime ";
		$sql .=" from zhsj_partion p inner join  zhsj_machine m ";
		$sql .=" on m.id=p.mid and m.status=1 and p.status=1 {$platform} {$zoneid} order by p.zoneid desc ";
		$result=$this->isql->query($sql);
		while($row=$result->fetch_assoc()){
			$row['usetime'] = date("Y-m-d H:i",$row['usetime']);
			$data[]=$row;
		}
		return $data;
	}
	function up_score($sid,$uid,$eid,$tp,$val)
	{
		$tbl = "score";
		$sql = "update ".$tbl." set val='".$val."' where sid='".$sid."' and uid='".$uid."' and eid='".$eid."' and tp='".$tp."' limit 1;"; 
		//echo $sql."<br>\n";
		$result=$this->osql->query($sql);
	}
	function get_score($sid,$uid,$eid,$tp)
	{
		$tbl = "score";
		$sql = "select val from ".$tbl." where sid='".$sid."' and uid='".$uid."' and eid='".$eid."' and tp='".$tp."' limit 1;"; 
		//echo $sql."<br>\n";
		$result=$this->osql->query($sql);
		if($result && $aRow = $result->fetch_assoc()){
			$val= $aRow['val'];
			return $val;
		}	
		$sql = "insert into ".$tbl." (sid,uid,eid,tp,val)values('".$sid."','".$uid."','".$eid."','".$tp."','0');"; 
		$result=$this->osql->query($sql);
		if(false==$result){return -1;}
		return 0;
	}
	function parseTime($str){
		$validTime0 = explode(" ",$str);
		if(!$validTime0)
			return false;
		$validTime1 = explode("-",$validTime0[0]);
		if(!empty($validTime0[1]))
		$validTime2 = @explode(":",$validTime0[1]);
		$t = mktime(intval($validTime2[0]),intval($validTime2[1]),intval($validTime2[2]),intval($validTime1[1]),intval($validTime1[2]),intval($validTime1[0]));
		return $t;
	}
	function getSID($game,$zone){
	return ($game<<16)+$zone;
	}
	function gbktoutf8($str){
		return iconv("GBK","UTF-8//IGNORE",$str);
	}
	function g_md16($str=""){
		//32λmd5�ַ���ת16λ,zll,2013-4-15
		//����:str:32λmd5
		//����:16λmd5
		if(32!=strlen($str)){return $str;}
		return substr($str,8,16);
	}
	function deescape ($s, $charset='UTF-8'){
		//  don't interpret html codes and don't convert quotes
		$s  =  htmlentities ($s, ENT_QUOTES, $charset);
		//  delete the inserted backslashes except those for protecting single quotes
		//$s  =  preg_replace ("/\\\\\\\\([^'])/e", '"&#" . ord("$1") . ";"', $s);
		//$s  =  preg_replace ("/\\\\\\\\([^'])/e", '"&#" . ord("$1") . ";"', $s);
		//$s  =  preg_replace_callback ("/\\\\\\\\([^'])/e",function($matches){return "";}, $s);
		//	function ($matches){
		//		return "";
		//		//return strtolower($matches[1]);
		//		//return '"&#" . ord("$matches[1]") . ";"';
		//	}, 

		//  delete the backslashes inserted for protecting single quotes
		$s  =  str_replace ("\\\\'", "&#" . ord ("'") . ";", $s);
		return  $s;
}
}	//end class
?>

